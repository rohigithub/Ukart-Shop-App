package com.pro.ukart.Controllers;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pro.ukart.Entities.Order;
import com.pro.ukart.Entities.Product;
import com.pro.ukart.Repositories.CategoryRepo;
import com.pro.ukart.Repositories.OrderRepo;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderRepo orderRepo;

    @GetMapping("/myorders")
    public ResponseEntity<List<Order>> getAllProducts() {
        List<Order> orders = orderRepo.findAll();
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/order/{id}")
    public ResponseEntity<Optional<Order>> getProduct(@PathVariable("id") Long id) {
        Optional<Order> order = orderRepo.findById(id);
        if (order.isPresent()) {
            return new ResponseEntity<>(order, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(order, HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/place_order")
    public ResponseEntity<Order> addProduct(@RequestBody Order order) {
        Order addedProduct = orderRepo.save(order);
        return new ResponseEntity<>(addedProduct, HttpStatus.OK);
    }

    @DeleteMapping("/order/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("id") Long id) {
        orderRepo.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

}
