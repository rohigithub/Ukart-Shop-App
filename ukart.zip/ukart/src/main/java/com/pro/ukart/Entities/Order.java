package com.pro.ukart.Entities;

import com.pro.ukart.Controllers.ProductController;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name = "Orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    private String name;
    private String address;
    private double totalAmount;
    private String contact;


    //@OneToMany
    //@JoinColumn(name = "cart_id")
    //@JsonIgnore
    //private Product productId;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    // @Override
    // public String toString() {
    //     return "Order [orderId=" + orderId + ", name=" + name + ", address=" + address + ", totalAmount=" + totalAmount
    //             + ", contact=" + contact + ", productId=" + productId + "]";
    // }

}
